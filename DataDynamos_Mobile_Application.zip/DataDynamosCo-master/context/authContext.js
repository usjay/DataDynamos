import React, { createContext, useState, useContext } from 'react';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthContext = createContext();

// Change this to your computer IP address
const localhost = 'http://192.168.1.127:3000';

export const AuthContextProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(undefined);

  const signUp = async (email, password) => {
    try {
      const response = await axios.post(`${localhost}/signUp`, { email, password });
      return { success: true, msg: response.data.message };
    } catch (error) {
      return { success: false, msg: error.message || 'Sign up failed' };
    }
  };

  const signIn = async (email, password) => {
    try {
      const response = await axios.post(`${localhost}/signIn`, { email, password });
      const { token } = response.data;
      await AsyncStorage.setItem('token', token);
      setIsAuthenticated(true);
      await fetchUser();
      return { success: true };
    } catch (error) {
      return { success: false, msg: error.response?.data?.message || 'Sign in failed' };
    }
  };

  const resetPassword = async (email) => {
    try {
      const response = await axios.post(`${localhost}/reset-password`, { email });
      return { success: true, msg: response.data.message };
    } catch (error) {
      return { success: false, msg: error.response?.data?.message || 'Password reset failed' };
    }
  };

  const signOut = async () => {
    await AsyncStorage.removeItem('token');
    setUser(null);
    setIsAuthenticated(false);
  };

  const fetchUser = async () => {
    const token = await AsyncStorage.getItem('token');
    if (!token) {
      setIsAuthenticated(false);
      return;
    }

    try {
      const response = await axios.get(`${localhost}/user`, {
        headers: { Authorization: token },
      });
      setUser(response.data);
      setIsAuthenticated(true);
    } catch (error) {
      setIsAuthenticated(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, signUp, signIn, resetPassword, signOut, fetchUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};