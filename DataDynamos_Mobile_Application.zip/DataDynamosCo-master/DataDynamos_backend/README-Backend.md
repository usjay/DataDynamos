# Welcome to Data Dynamos & Co App Backend 👋

## Get started

1. Import SQL file to mySQL server and create the database

2. Open the backend directory in Terminal (CMD/Powershell) 
   
2. Install dependencies

   ```bash
   npm install
   ```

4. Run the server

   ```bash
    npm start
   ```