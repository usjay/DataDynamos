const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer'); 
require('dotenv').config(); 

const app = express();
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'data_dynamos_db'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL connected...');

});

const JWT_SECRET = 'O7ZPhmv8XA';

// User sign-up
app.post('/signup', async (req, res) => {
    const { email, password } = req.body;
  
    if (!email || !password ) {
      return res.status(400).json({ message: 'Please provide all required fields' });
    }
  
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const query = 'INSERT INTO users (email, password) VALUES (?, ?)';
      db.query(query, [email, hashedPassword], (err, results) => {
        if (err) {
          return res.status(500).json({ message: 'Error signing up user', error: err.message });
        }
        res.status(201).json({ message: 'User signed up successfully' });
      });
    } catch (error) {
      res.status(500).json({ message: 'Error signing up user', error: error.message });
    }
  });

// User sign-in
app.post('/signin', (req, res) => {
  const { email, password } = req.body;
  const query = 'SELECT * FROM users WHERE email = ?';
  db.query(query, [email], async (err, results) => {
    if (err) throw err;
    if (results.length === 0) {
      return res.status(400).json({ message: 'User not found' });
    }
    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid password' });
    }
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
  });
});

// Middleware to verify JWT
const authenticate = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) {
    return res.status(401).json({ message: 'Access denied' });
  }
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Failed to authenticate token' });
    }
    req.user = decoded;
    next();
  });
};

// Fetch user data
app.get('/user', authenticate, (req, res) => {
  const query = 'SELECT id, email FROM users WHERE id = ?';
  db.query(query, [req.user.id], (err, results) => {
    if (err) throw err;
    res.json(results[0]);
  });
});

// Device routes
app.get('/devices', authenticate, (req, res) => {
  const query = 'SELECT * FROM devices WHERE user_id = ?';
  db.query(query, [req.user.id], (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

app.post('/devices', authenticate, (req, res) => {
  const { name, image } = req.body;
  const query = 'INSERT INTO devices (user_id, name, image) VALUES (?, ?, ?)';
  db.query(query, [req.user.id, name, image], (err, results) => {
    if (err) throw err;
    res.json({ id: results.insertId, user_id: req.user.id, name, image });
  });
});

// Delete Device
app.delete('/devices/:id', authenticate, (req, res) => {
  const { id } = req.params;

  // Start a transaction
  db.beginTransaction(err => {
    if (err) throw err;

    // Delete preferences first
    const deletePreferencesQuery = 'DELETE FROM preferences WHERE device_id = ?';
    db.query(deletePreferencesQuery, [id], (err, results) => {
      if (err) {
        return db.rollback(() => {
          throw err;
        });
      }

      // Delete the device
      const deleteDeviceQuery = 'DELETE FROM devices WHERE id = ? AND user_id = ?';
      db.query(deleteDeviceQuery, [id, req.user.id], (err, results) => {
        if (err) {
          return db.rollback(() => {
            throw err;
          });
        }

        db.commit(err => {
          if (err) {
            return db.rollback(() => {
              throw err;
            });
          }
          res.json({ message: 'Device and related preferences deleted successfully' });
        });
      });
    });
  });
});

// Preference routes
app.get('/preferences', authenticate, (req, res) => {
  const { device_id } = req.query; // Access device_id from query parameters
  const query = 'SELECT * FROM preferences WHERE device_id=? AND user_id = ?';
  db.query(query, [device_id, req.user.id], (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

app.post('/preferences', authenticate, (req, res) => {
  const { device_id, day, night } = req.body;
  const query = 'INSERT INTO preferences (device_id, user_id, day, night) VALUES (?, ?, ?, ?)';
  db.query(query, [device_id, req.user.id, day, night], (err, results) => {
    if (err) throw err;
    res.json({ id: results.insertId, device_id, user_id: req.user.id, day, night });
  });
});

app.put('/preferences/:id', authenticate, (req, res) => {
  const { id } = req.params;
  const { day, night } = req.body;
  const updates = [];
  const values = [];

  if (day !== undefined) {
    updates.push('day = ?');
    values.push(day);
  }
  if (night !== undefined) {
    updates.push('night = ?');
    values.push(night);
  }

  if (updates.length === 0) {
    return res.status(400).json({ success: false, message: 'No fields to update' });
  }

  values.push(id, req.user.id);
  const query = `UPDATE preferences SET ${updates.join(', ')} WHERE device_id = ? AND user_id = ?`;

  db.query(query, values, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: 'Failed to update preference' });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Preference not found or user unauthorized' });
    }
    res.json({ success: true, message: 'Preference updated successfully' });
  });
});

// Password reset
app.post('/reset-password', async (req, res) => {
    const { email } = req.body;
  
    if (!email) {
      return res.status(400).json({ message: 'Please provide an email address' });
    }
  
    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], async (err, results) => {
      if (err) throw err;
  
      if (results.length === 0) {
        return res.status(400).json({ message: 'User not found' });
      }
  
      const user = results[0];
      const resetToken = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '15m' });
  
      // Send reset email using nodemailer
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.EMAIL,
          pass: process.env.EMAIL_PASSWORD
        }
      });
  
      const mailOptions = {
        from: process.env.EMAIL,
        to: user.email,
        subject: 'Password Reset',
        text: `You requested a password reset. Click the link to reset your password: http://192.168.1.127:3000/reset-password/${resetToken}`
      };
  
      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          return res.status(500).json({ message: 'Error sending email', error: error.message });
        }
        res.json({ message: 'Password reset email sent' });
      });
    });
  });

app.listen(3000, () => {
  console.log('Server running on port 3000');
});