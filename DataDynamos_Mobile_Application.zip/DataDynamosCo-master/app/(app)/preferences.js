import { View, Text, Image, Switch, ActivityIndicator, ScrollView, Alert } from 'react-native';
import React, { useEffect, useState } from 'react';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { useAuth } from '../../context/authContext';
import axios from 'axios';
import Background from '../../components/Background';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Preferences() {
  const { user } = useAuth();
  const [devices, setDevices] = useState([]);
  const [preferences, setPreferences] = useState({});
  const [loading, setLoading] = useState(true);

  const localhost = 'http://192.168.1.127:3000';

  useEffect(() => {
    // Load devices and preferences 
    const fetchDevicesAndPreferences = async () => {
      if (user) {
        try {
          const token = await AsyncStorage.getItem('token');
          const devicesResponse = await axios.get(`${localhost}/devices`, {
            headers: { Authorization: token },
            params: { user_id: user.uid },
          });

          const fetchedDevices = devicesResponse.data;
          const fetchedPreferences = {};

          for (const device of fetchedDevices) {
            const preferencesResponse = await axios.get(`${localhost}/preferences`, {
              headers: { Authorization: token },
              params: { device_id: device.id },
            });

            if (preferencesResponse.data.length > 0) {
              const preferenceData = preferencesResponse.data[0];
              fetchedPreferences[device.id] = {
                day: preferenceData.day,
                night: preferenceData.night,
              };
            }
            console.log(fetchedPreferences);
          }

          setDevices(fetchedDevices);
          setPreferences(fetchedPreferences);
        } catch (error) {
          console.error('Error fetching devices and preferences:', error);
        }
      }
      
      setLoading(false);
    };

    fetchDevicesAndPreferences();
  }, [user]);

  const toggleSwitch = async (deviceId, type) => {
    const updatedPreferences = { ...preferences };
    updatedPreferences[deviceId][type] = !updatedPreferences[deviceId][type];
    setPreferences(updatedPreferences);

    // Update the preference in the backend
    try {
      const token = await AsyncStorage.getItem('token');
      // const preferenceId = updatedPreferences[deviceId].id;
      const response = await axios.put(`${localhost}/preferences/${deviceId}`, { [type]: updatedPreferences[deviceId][type] }, {
        headers: { Authorization: token },
      });
  
      if (response.data.success) {
        console.log(response.data.message);
      } else {
        Alert.alert("Error", response.data.message);
        console.log(response.data.message);
      }
    } catch (error) {
      Alert.alert("Error", "Failed to update preference");
      console.error('Error updating preference:', error);
    }
  };

  if (loading) {
    return (
      <View className="flex-1 justify-center items-center">
        <ActivityIndicator size="large" color="#525252" />
      </View>
    );
  }

  return (
    <Background>
      <View className="items-center mt-12 gap-11 h-1/5">
        <Text className="text-white text-s font-semibold">Data Dynamos & Co</Text>
        <View className="flex-1 justify-center">
          <Text style={{ fontSize: hp(4) }} className="text-black font-bold">Preferences</Text>
        </View>
      </View>
      <View className="flex-row justify-around items-center w-full my-4">
        <Text style={{ fontSize: hp(3) }} className="text-neutral-500 font-bold">Day</Text>
        <Text style={{ fontSize: hp(3) }} className="text-neutral-500 font-bold">Night</Text>
      </View>
      <ScrollView>
        <View className="flex-1 items-center w-full">
          {devices.length === 0 ? (
            <Text style={{ fontSize: hp(2) }} className="text-neutral-700 font-bold mb-5">There are no devices</Text>
          ) : (
            <View className="flex-row flex-wrap justify-around">
              {devices.map((device) => (
                <React.Fragment key={device.id}>
                  <View className="flex items-center mb-2">
                    <Text className="text-black text-s my-2">{device.name}</Text>
                    <View style={{ height: hp(15), width: wp(50) }} className="rounded-lg px-12 p-2 relative">
                      <Image
                        source={{ uri: device.image }}
                        className="w-full h-full object-cover rounded-2xl border-4 border-white"
                      />
                      {/* Toggle Button */}
                      <Switch
                        style={{
                          position: 'absolute',
                          bottom: 10,
                          right: 40,
                          transform: [{ scaleX: .6 }, { scaleY: .6 }]
                        }}
                        trackColor={{ false: '#767577', true: '#FFFFFF' }}
                        thumbColor={preferences[device.id]?.day === 1 ? '#222222' : '#f4f3f4'}
                        ios_backgroundColor="#3e3e3e"
                        onValueChange={() => toggleSwitch(device.id, 'day')}
                        value={preferences[device.id]?.day === 1}
                      />
                    </View>
                  </View>
                  <View className="flex items-center mb-2">
                    <Text className="text-black text-s my-2">{device.name}</Text>
                    <View style={{ height: hp(15), width: wp(50) }} className="rounded-lg px-12 p-2 relative">
                      <Image
                        source={{ uri: device.image }}
                        className="w-full h-full object-cover rounded-2xl border-4 border-white"
                      />
                      <Switch
                        style={{
                          position: 'absolute',
                          bottom: 10,
                          right: 40,
                          transform: [{ scaleX: .6 }, { scaleY: .6 }]
                        }}
                        trackColor={{ false: '#767577', true: '#FFFFFF' }}
                        thumbColor={preferences[device.id]?.night === 1 ? '#222222' : '#f4f3f4'}
                        ios_backgroundColor="#3e3e3e"
                        onValueChange={() => toggleSwitch(device.id, 'night')}
                        value={preferences[device.id]?.night === 1}
                      />
                    </View>
                  </View>
                </React.Fragment>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </Background>
  );
}