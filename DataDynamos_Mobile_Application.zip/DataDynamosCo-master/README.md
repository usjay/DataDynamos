# Welcome to Data Dynamos & Co App 👋

This is an [Expo](https://expo.dev) project created with [`create-expo-app`](https://www.npmjs.com/package/create-expo-app).

## Get started

1. Install expo and eas globally.
   
   ```bash
   npm install --global expo-cli eas-cli
   ```
2. Open the backend directory in Terminal (CMD/Powershell)

3. Install dependencies

   ```bash
   npm install
   ```

4. Configure the database and backend

5. Change the localhost to your computer IP address in authContext, devices, addDevice, preferences files.

6. Start the app and scan using expo go app

   ```bash
    npx expo start
   ```